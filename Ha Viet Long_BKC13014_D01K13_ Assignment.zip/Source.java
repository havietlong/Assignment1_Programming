import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Point;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Date;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.JScrollPane;
import javax.swing.border.BevelBorder;
import java.awt.Color;
import javax.swing.UIManager;
import java.awt.SystemColor;
import javax.swing.JCheckBox;
import javax.swing.JRadioButton;
import javax.swing.JToolBar;
import javax.swing.RowFilter;
import javax.swing.JMenuItem;
import javax.swing.JMenu;
import javax.swing.SwingConstants;
import javax.swing.JMenuBar;
import javax.swing.JLayeredPane;
import java.awt.event.MouseAdapter;
import java.awt.event.InputMethodListener;
import java.awt.event.InputMethodEvent;
import com.toedter.calendar.JDayChooser;
import com.toedter.calendar.JDateChooser;

public class PhoneSortingSystem extends JFrame {
	private JPanel contentPane;
	private JTextField txtImei;
	private JTable table;
	private JButton btnNewButton_1;
	private JTextField txtName;
	private JTextField txtManufacturer;
	private JTextField txtPrice;
	private JTextField txtRam;
	private JTextField txtRom;
	private JTextField txtChip;
	private JTextField txtScreenSize;
	private JTextField txtPhoneSize;
	private JButton btnNewButton_2;
	private JButton btnNewButton_3;
	private JMenuBar menuBar;
	private JMenu mnNewMenu_1;
	private JMenuItem mntmNewMenuItem_4;
	private JMenuItem mntmNewMenuItem_5;
	private JMenuItem mntmNewMenuItem_6;
	private JMenuItem mntmNewMenuItem_7;
	JDateChooser dateChooser1 = new JDateChooser();
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PhoneSortingSystem frame = new PhoneSortingSystem();
					frame.setVisible(true);
					frame.setResizable(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PhoneSortingSystem() {
		table = new JTable();
		table.setAutoCreateRowSorter(true);
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				int i = table.getSelectedRow();
				txtImei.setText(model.getValueAt(i, 1).toString());
				txtChip.setText(model.getValueAt(i, 8).toString());
				txtManufacturer.setText(model.getValueAt(i, 3).toString());
				txtPhoneSize.setText(model.getValueAt(i, 10).toString());
				txtPrice.setText(model.getValueAt(i, 4).toString());
				txtScreenSize.setText(model.getValueAt(i, 9).toString());
				txtRom.setText(model.getValueAt(i, 7).toString());
				txtRam.setText(model.getValueAt(i, 6).toString());
				dateChooser1.setDate( (Date) model.getValueAt(i, 5));
				txtName.setText(model.getValueAt(i, 2).toString());
			}
		});
		setTitle("HirePhone Phone Manager");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1064, 619);
		
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("Phones");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("New menu item");
		mnNewMenu.add(mntmNewMenuItem);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("New menu item");
		mnNewMenu.add(mntmNewMenuItem_1);
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("New menu item");
		mnNewMenu.add(mntmNewMenuItem_2);
		
		JMenuItem mntmNewMenuItem_3 = new JMenuItem("New menu item");
		mnNewMenu.add(mntmNewMenuItem_3);
		
		mnNewMenu_1 = new JMenu("Tools");
		menuBar.add(mnNewMenu_1);
		
		mntmNewMenuItem_4 = new JMenuItem("FIlter by Manufactorer");
		mnNewMenu_1.add(mntmNewMenuItem_4);
		mntmNewMenuItem_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
			   String manuFacturer = JOptionPane.showInputDialog(null, "Manufacturer: ", "FIlter by Manufactorer", JOptionPane.QUESTION_MESSAGE);
			   final TableRowSorter<TableModel> sorter = new TableRowSorter<>(model);
			   table.setRowSorter(sorter);
			   if(manuFacturer.length()==0) {
				   sorter.setRowFilter(null);
			   }
			   else {
				   sorter.setRowFilter(RowFilter.regexFilter(manuFacturer));
			   }
			}
		});
		
		mntmNewMenuItem_5 = new JMenuItem("Order by Release Date desc");
		mntmNewMenuItem_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame f =new JFrame();  
			    JOptionPane.showMessageDialog(f,"Click on RELEASE DATE to Sort");  	
			}
		});
		
		mnNewMenu_1.add(mntmNewMenuItem_5);
		
		mntmNewMenuItem_6 = new JMenuItem("Filter by Price");
		mnNewMenu_1.add(mntmNewMenuItem_6);
		mntmNewMenuItem_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
			   String manuFacturer = JOptionPane.showInputDialog(null, "Price: ", "FIlter by Price", JOptionPane.QUESTION_MESSAGE);
			   final TableRowSorter<TableModel> sorter = new TableRowSorter<>(model);
			   table.setRowSorter(sorter);
			   if(manuFacturer.length()==0) {
				   sorter.setRowFilter(null);
			   }
			   else {
				   sorter.setRowFilter(RowFilter.regexFilter(manuFacturer));
			   }
			}
		});
		
		mntmNewMenuItem_7 = new JMenuItem("Order by Price desc");
		mntmNewMenuItem_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame f =new JFrame();  
			    JOptionPane.showMessageDialog(f,"Click on PRICE Column Header to Sort ");  	
			}
		});
	
		mnNewMenu_1.add(mntmNewMenuItem_7);
		contentPane = new JPanel();
		contentPane.setBackground(SystemColor.menu);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		JPanel panel = new JPanel();
		panel.setBackground(new Color(185, 209, 234));
		panel.setBounds(0, 0, 1050, 577);
		contentPane.add(panel);
		panel.setLayout(null);
		txtImei = new JTextField();
		
		
		txtImei.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				switch (txtImei.getText()) {
				case "IMEI":txtImei.setText("");
				}
				
				
				if(txtName.getText().length()<=0) {
					txtName.setText("NAME");
				}
				else {
					txtName.getText();
				}
				
				if(txtManufacturer.getText().length()<=0) {
					txtManufacturer.setText("MANUFACTURER");
				}
				else {
					txtManufacturer.getText();
				}
				
				if(txtChip.getText().length()<=0) {
					txtChip.setText("Chip");
				}
				else {
					txtChip.getText();
				}
				
				if(txtPhoneSize.getText().length()<=0) {
					txtPhoneSize.setText("PHONE SIZE");
				}
				else {
					txtPhoneSize.getText();
				}
				
				if(txtPrice.getText().length()<=0) {
					txtPrice.setText("PRICE");
				}
				else {
					txtPrice.getText();
				}
				
				if(txtRam.getText().length()<=0) {
					txtRam.setText("RAM");
				}
				else {
					txtRam.getText();
				}
				
				if(txtRom.getText().length()<=0) {
					txtRom.setText("ROM");
				}
				else {
					txtRom.getText();
				}
				
				if(dateChooser1.getDate()==null) {
					dateChooser1.setDate(null);
				}
				else {
					dateChooser1.getDate();
				}
				if(txtScreenSize.getText().length()<=0) {
					txtScreenSize.setText("SCREEN SIZE");
				}
				else {
					txtScreenSize.getText();
				}
			}
		});
		
		
		txtImei.setText("IMEI");
		txtImei.setBounds(10, 22, 264, 38);
		panel.add(txtImei);
		txtImei.setColumns(10);
		
		JButton btnNewButton = new JButton("Insert Phone");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				txtChip.setText("CHIP");
				txtImei.setText("IMEI");
				txtManufacturer.setText("MANUFACTURER");
				txtName.setText("NAME");
				txtPhoneSize.setText("PHONE SIZE");
				txtScreenSize.setText("SCREEN SIZE");
				txtPrice.setText("PRICE");
				txtRam.setText("RAM");
				txtRom.setText("ROM");
				dateChooser1.setDate(null);
			}
		});
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(txtImei.getText().isEmpty()||txtImei.getText().matches("IMEI")) {
				  JFrame f =new JFrame();  
				    JOptionPane.showMessageDialog(f,"Please fill in all datas");  	
				}
				else if(txtChip.getText().isEmpty()||txtChip.getText().matches("CHIP")){
					 JFrame f =new JFrame();  
					    JOptionPane.showMessageDialog(f,"Please fill in all datas");  
				}
				else if(txtManufacturer.getText().isEmpty()||txtManufacturer.getText().matches("MANUFACTURER")){
					 JFrame f =new JFrame();  
					    JOptionPane.showMessageDialog(f,"Please fill in all datas");  
				}
				else if(txtName.getText().isEmpty()||txtName.getText().matches("NAME")){
					 JFrame f =new JFrame();  
					    JOptionPane.showMessageDialog(f,"Please fill in all datas");  
				}
				else if(txtPhoneSize.getText().isEmpty()||txtPhoneSize.getText().matches("PHONE SIZE")){
					 JFrame f =new JFrame();  
					    JOptionPane.showMessageDialog(f,"Please fill in all datas");  
				}
				else if(txtPrice.getText().isEmpty()||txtPrice.getText().matches("PRICE")){
					 JFrame f =new JFrame();  
					    JOptionPane.showMessageDialog(f,"Please fill in all datas");  
				}
				else if(txtRam.getText().isEmpty()||txtRam.getText().matches("RAM")){
					 JFrame f =new JFrame();  
					    JOptionPane.showMessageDialog(f,"Please fill in all datas");  
				}
				else if(dateChooser1.getDate()==null){
					 JFrame f =new JFrame();  
					    JOptionPane.showMessageDialog(f,"Please fill in all datas");  
				}
				else if(txtRom.getText().isEmpty()||txtRom.getText().matches("ROM")){
					 JFrame f =new JFrame();  
					    JOptionPane.showMessageDialog(f,"Please fill in all datas");  
				}
				else if(txtScreenSize.getText().isEmpty()||txtScreenSize.getText().matches("SCREEN SIZE")){
					 JFrame f =new JFrame();  
					    JOptionPane.showMessageDialog(f,"Please fill in all datas");  
				}
			else{
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				model.addRow(new Object[] { 
						model.getRowCount()+1,
						txtImei.getText(),
						txtName.getText(),
						txtManufacturer.getText(),
						txtPrice.getText(),
						dateChooser1.getDate(),
						txtRam.getText(),
						txtRom.getText(),
						txtChip.getText(),
						txtScreenSize.getText(),
						txtPhoneSize.getText(),
			});
			}
			}
		});
		btnNewButton.setBounds(350, 502, 165, 44);
		panel.add(btnNewButton);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(287, 10, 753, 482);
		panel.add(scrollPane);
		
		
		scrollPane.setViewportView(table);
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"No.", "IMEI", "Name", "Manufacturer", "Price", "Release date", "RAM capacity", "ROM capacity", "Chip", "Screen size", "Phone size "
			}
		) {
			Class[] columnTypes = new Class[] {
				Integer.class, Integer.class, String.class, String.class, Integer.class, Object.class, Integer.class, Integer.class, String.class, Integer.class, Integer.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		}
		);
		
		btnNewButton_1 = new JButton("Delete Phone");
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				txtChip.setText("CHIP");
				txtImei.setText("IMEI");
				txtManufacturer.setText("MANUFACTURER");
				txtName.setText("NAME");
				txtPhoneSize.setText("PHONE SIZE");
				txtScreenSize.setText("SCREEN SIZE");
				txtPrice.setText("PRICE");
				txtRam.setText("RAM");
				txtRom.setText("ROM");
				dateChooser1.setDate(null);
			}
		});
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				int i = table.getSelectedRow();
				if(i>=0) {
				model.removeRow(i);
				}
				else {
					 JFrame f =new JFrame();  
					    JOptionPane.showMessageDialog(f,"Please select data to delete");  
				}
			}
		});
		
		btnNewButton_1.setBounds(525, 502, 165, 44);
		panel.add(btnNewButton_1);
		
		txtName = new JTextField();
		txtName.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(txtImei.getText().length()<=0)
				txtImei.setText("IMEI");
				else {
					txtImei.getText();
				}
				if(txtManufacturer.getText().length()<=0) {
					txtManufacturer.setText("MANUFACTURER");
				}
				else {
					txtManufacturer.getText();
				}
				
				if(txtChip.getText().length()<=0) {
					txtChip.setText("Chip");
				}
				else {
					txtChip.getText();
				}
				
				if(txtPhoneSize.getText().length()<=0) {
					txtPhoneSize.setText("PHONE SIZE");
				}
				else {
					txtPhoneSize.getText();
				}
				
				if(txtPrice.getText().length()<=0) {
					txtPrice.setText("PRICE");
				}
				else {
					txtPrice.getText();
				}
				
				if(txtRam.getText().length()<=0) {
					txtRam.setText("RAM");
				}
				else {
					txtRam.getText();
				}
				
				if(txtRom.getText().length()<=0) {
					txtRom.setText("ROM");
				}
				else {
					txtRom.getText();
				}
				
				if(dateChooser1.getDate()==null) {
					dateChooser1.setDate(null);
				}
				else {
					dateChooser1.getDate();
				}
				if(txtScreenSize.getText().length()<=0) {
					txtScreenSize.setText("SCREEN SIZE");
				}
				else {
					txtScreenSize.getText();
				}
				
				
				switch (txtName.getText()) {
				case "NAME":txtName.setText("");
				}
			}
		});
		txtName.setText("NAME");
		txtName.setColumns(10);
		txtName.setBounds(10, 70, 264, 38);
		panel.add(txtName);
		
		
		txtManufacturer = new JTextField();
		txtManufacturer.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(txtName.getText().length()<=0) {
					txtName.setText("NAME");
				}
				else {
					txtName.getText();
				}
				
				if(txtManufacturer.getText().length()<=0) {
					txtManufacturer.setText("MANUFACTURER");
				}
				else {
					txtManufacturer.getText();
				}
				
				if(txtChip.getText().length()<=0) {
					txtChip.setText("Chip");
				}
				else {
					txtChip.getText();
				}
				
				if(txtPhoneSize.getText().length()<=0) {
					txtPhoneSize.setText("PHONE SIZE");
				}
				else {
					txtPhoneSize.getText();
				}
				
				if(txtPrice.getText().length()<=0) {
					txtPrice.setText("PRICE");
				}
				else {
					txtPrice.getText();
				}
				
				if(txtRam.getText().length()<=0) {
					txtRam.setText("RAM");
				}
				else {
					txtRam.getText();
				}
				
				if(txtRom.getText().length()<=0) {
					txtRom.setText("ROM");
				}
				else {
					txtRom.getText();
				}
				
				if(dateChooser1.getDate()==null) {
					dateChooser1.setDate(null);
				}
				else {
					dateChooser1.getDate();
				}
				if(txtScreenSize.getText().length()<=0) {
					txtScreenSize.setText("SCREEN SIZE");
				}
				else {
					txtScreenSize.getText();
				}
				
				switch (txtManufacturer.getText()) {
				case "MANUFACTURER":txtManufacturer.setText("");
				}
			}
		});
		txtManufacturer.setText("MANUFACTURER");
		txtManufacturer.setColumns(10);
		txtManufacturer.setBounds(10, 118, 264, 38);
		panel.add(txtManufacturer);
		
		txtPrice = new JTextField();
		txtPrice.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(txtName.getText().length()<=0) {
					txtName.setText("NAME");
				}
				else {
					txtName.getText();
				}
				
				if(txtManufacturer.getText().length()<=0) {
					txtManufacturer.setText("MANUFACTURER");
				}
				else {
					txtManufacturer.getText();
				}
				
				if(txtChip.getText().length()<=0) {
					txtChip.setText("Chip");
				}
				else {
					txtChip.getText();
				}
				
				if(txtPhoneSize.getText().length()<=0) {
					txtPhoneSize.setText("PHONE SIZE");
				}
				else {
					txtPhoneSize.getText();
				}
				
				if(txtPrice.getText().length()<=0) {
					txtPrice.setText("PRICE");
				}
				else {
					txtPrice.getText();
				}
				
				if(txtRam.getText().length()<=0) {
					txtRam.setText("RAM");
				}
				else {
					txtRam.getText();
				}
				
				if(txtRom.getText().length()<=0) {
					txtRom.setText("ROM");
				}
				else {
					txtRom.getText();
				}
				
				if(dateChooser1.getDate()==null) {
					dateChooser1.setDate(null);
				}
				else {
					dateChooser1.getDate();
				}
				if(txtScreenSize.getText().length()<=0) {
					txtScreenSize.setText("SCREEN SIZE");
				}
				else {
					txtScreenSize.getText();
				}
				
				switch (txtPrice.getText()) {
				case "PRICE":txtPrice.setText("");
				}
			}
		});
		txtPrice.setText("PRICE");
		txtPrice.setColumns(10);
		txtPrice.setBounds(10, 166, 264, 38);
		panel.add(txtPrice);
		
		txtRam = new JTextField();
		txtRam.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(txtName.getText().length()<=0) {
					txtName.setText("NAME");
				}
				else {
					txtName.getText();
				}
				
				if(txtManufacturer.getText().length()<=0) {
					txtManufacturer.setText("MANUFACTURER");
				}
				else {
					txtManufacturer.getText();
				}
				
				if(txtChip.getText().length()<=0) {
					txtChip.setText("Chip");
				}
				else {
					txtChip.getText();
				}
				
				if(txtPhoneSize.getText().length()<=0) {
					txtPhoneSize.setText("PHONE SIZE");
				}
				else {
					txtPhoneSize.getText();
				}
				
				if(txtPrice.getText().length()<=0) {
					txtPrice.setText("PRICE");
				}
				else {
					txtPrice.getText();
				}
				
				if(txtRam.getText().length()<=0) {
					txtRam.setText("RAM");
				}
				else {
					txtRam.getText();
				}
				
				if(txtRom.getText().length()<=0) {
					txtRom.setText("ROM");
				}
				else {
					txtRom.getText();
				}
				
				if(dateChooser1.getDate()==null) {
					dateChooser1.setDate(null);
				}
				else {
					dateChooser1.getDate();
				}
				if(txtScreenSize.getText().length()<=0) {
					txtScreenSize.setText("SCREEN SIZE");
				}
				else {
					txtScreenSize.getText();
				}
				
				switch (txtRam.getText()) {
				case "RAM":txtRam.setText("");
			}
			}
		});
		txtRam.setText("RAM");
		txtRam.setColumns(10);
		txtRam.setBounds(10, 262, 264, 38);
		panel.add(txtRam);
		
		txtRom = new JTextField();
		txtRom.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(txtName.getText().length()<=0) {
					txtName.setText("NAME");
				}
				else {
					txtName.getText();
				}
				
				if(txtManufacturer.getText().length()<=0) {
					txtManufacturer.setText("MANUFACTURER");
				}
				else {
					txtManufacturer.getText();
				}
				
				if(txtChip.getText().length()<=0) {
					txtChip.setText("Chip");
				}
				else {
					txtChip.getText();
				}
				
				if(txtPhoneSize.getText().length()<=0) {
					txtPhoneSize.setText("PHONE SIZE");
				}
				else {
					txtPhoneSize.getText();
				}
				
				if(txtPrice.getText().length()<=0) {
					txtPrice.setText("PRICE");
				}
				else {
					txtPrice.getText();
				}
				
				if(txtRam.getText().length()<=0) {
					txtRam.setText("RAM");
				}
				else {
					txtRam.getText();
				}
				
				if(txtRom.getText().length()<=0) {
					txtRom.setText("ROM");
				}
				else {
					txtRom.getText();
				}
				
				if(dateChooser1.getDate()==null) {
					dateChooser1.setDate(null);
				}
				else {
					dateChooser1.getDate();
				}
				if(txtScreenSize.getText().length()<=0) {
					txtScreenSize.setText("SCREEN SIZE");
				}
				else {
					txtScreenSize.getText();
				}
				
				switch (txtRom.getText()) {
				case "ROM":txtRom.setText("");
				}
			}
		});
		txtRom.setText("ROM");
		txtRom.setColumns(10);
		txtRom.setBounds(10, 310, 264, 38);
		panel.add(txtRom);
		
		txtChip = new JTextField();
		txtChip.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(txtName.getText().length()<=0) {
					txtName.setText("NAME");
				}
				else {
					txtName.getText();
				}
				
				if(txtManufacturer.getText().length()<=0) {
					txtManufacturer.setText("MANUFACTURER");
				}
				else {
					txtManufacturer.getText();
				}
				
				if(txtChip.getText().length()<=0) {
					txtChip.setText("Chip");
				}
				else {
					txtChip.getText();
				}
				
				if(txtPhoneSize.getText().length()<=0) {
					txtPhoneSize.setText("PHONE SIZE");
				}
				else {
					txtPhoneSize.getText();
				}
				
				if(txtPrice.getText().length()<=0) {
					txtPrice.setText("PRICE");
				}
				else {
					txtPrice.getText();
				}
				
				if(txtRam.getText().length()<=0) {
					txtRam.setText("RAM");
				}
				else {
					txtRam.getText();
				}
				
				if(txtRom.getText().length()<=0) {
					txtRom.setText("ROM");
				}
				else {
					txtRom.getText();
				}
				
				if(dateChooser1.getDate()==null) {
					dateChooser1.setDate(null);
				}
				else {
					dateChooser1.getDate();
				}
				if(txtScreenSize.getText().length()<=0) {
					txtScreenSize.setText("SCREEN SIZE");
				}
				else {
					txtScreenSize.getText();
				}
				
				switch (txtChip.getText()) {
				case "CHIP":txtChip.setText("");
				}
			}
		});
		txtChip.setText("CHIP");
		txtChip.setColumns(10);
		txtChip.setBounds(10, 358, 264, 38);
		panel.add(txtChip);
		
		txtScreenSize = new JTextField();
		txtScreenSize.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(txtName.getText().length()<=0) {
					txtName.setText("NAME");
				}
				else {
					txtName.getText();
				}
				
				if(txtManufacturer.getText().length()<=0) {
					txtManufacturer.setText("MANUFACTURER");
				}
				else {
					txtManufacturer.getText();
				}
				
				if(txtChip.getText().length()<=0) {
					txtChip.setText("Chip");
				}
				else {
					txtChip.getText();
				}
				
				if(txtPhoneSize.getText().length()<=0) {
					txtPhoneSize.setText("PHONE SIZE");
				}
				else {
					txtPhoneSize.getText();
				}
				
				if(txtPrice.getText().length()<=0) {
					txtPrice.setText("PRICE");
				}
				else {
					txtPrice.getText();
				}
				
				if(txtRam.getText().length()<=0) {
					txtRam.setText("RAM");
				}
				else {
					txtRam.getText();
				}
				
				if(txtRom.getText().length()<=0) {
					txtRom.setText("ROM");
				}
				else {
					txtRom.getText();
				}
				
				if(dateChooser1.getDate()==null) {
					dateChooser1.setDate(null);
				}
				else {
					dateChooser1.getDate();
				}
				if(txtScreenSize.getText().length()<=0) {
					txtScreenSize.setText("SCREEN SIZE");
				}
				else {
					txtScreenSize.getText();
				}
				
				switch (txtScreenSize.getText()) {
				case "SCREEN SIZE":txtScreenSize.setText("");
				}
			}
		});
		txtScreenSize.setText("SCREEN SIZE");
		txtScreenSize.setColumns(10);
		txtScreenSize.setBounds(10, 406, 264, 38);
		panel.add(txtScreenSize);
		
		txtPhoneSize = new JTextField();
		txtPhoneSize.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if(txtName.getText().length()<=0) {
					txtName.setText("NAME");
				}
				else {
					txtName.getText();
				}
				
				if(txtManufacturer.getText().length()<=0) {
					txtManufacturer.setText("MANUFACTURER");
				}
				else {
					txtManufacturer.getText();
				}
				
				if(txtChip.getText().length()<=0) {
					txtChip.setText("Chip");
				}
				else {
					txtChip.getText();
				}
				
				if(txtPhoneSize.getText().length()<=0) {
					txtPhoneSize.setText("PHONE SIZE");
				}
				else {
					txtPhoneSize.getText();
				}
				
				if(txtPrice.getText().length()<=0) {
					txtPrice.setText("PRICE");
				}
				else {
					txtPrice.getText();
				}
				
				if(txtRam.getText().length()<=0) {
					txtRam.setText("RAM");
				}
				else {
					txtRam.getText();
				}
				
				if(txtRom.getText().length()<=0) {
					txtRom.setText("ROM");
				}
				else {
					txtRom.getText();
				}
				
				if(dateChooser1.getDate()==null) {
					dateChooser1.setDate(null);
				}
				else {
					dateChooser1.getDate();
				}
				if(txtScreenSize.getText().length()<=0) {
					txtScreenSize.setText("SCREEN SIZE");
				}
				else {
					txtScreenSize.getText();
				}
				
				switch (txtPhoneSize.getText()) {
				case "PHONE SIZE":txtPhoneSize.setText("");
				}
			}
		});
		txtPhoneSize.setText("PHONE SIZE");
		txtPhoneSize.setColumns(10);
		txtPhoneSize.setBounds(10, 454, 264, 38);
		panel.add(txtPhoneSize);
		
		btnNewButton_2 = new JButton("Update Phone");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				int i = table.getSelectedRow();
				model.setValueAt(txtImei.getText(), i, 1);
				model.setValueAt(txtChip.getText(), i, 8);
				model.setValueAt(txtManufacturer.getText(), i, 3);
				model.setValueAt(txtName.getText(), i, 2);
				model.setValueAt(txtPhoneSize.getText(), i, 10);
				model.setValueAt(txtPrice.getText(), i, 4);
				model.setValueAt(txtRam.getText(), i, 6);
				model.setValueAt(dateChooser1.getDate(),i,5);
				model.setValueAt(txtRom.getText(), i, 7);
				model.setValueAt(txtScreenSize.getText(), i, 9);
				
			}
		});
		
		
		btnNewButton_2.setBounds(700, 502, 165, 44);
		panel.add(btnNewButton_2);
		
		btnNewButton_3 = new JButton("Display All");
		btnNewButton_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				DefaultTableModel model = (DefaultTableModel) table.getModel();
				final TableRowSorter<TableModel> sorter = new TableRowSorter<>(model);
				table.setRowSorter(sorter);
				sorter.setRowFilter(null);
			}
		});
		btnNewButton_3.setBounds(875, 502, 165, 44);
		panel.add(btnNewButton_3);
		
		
		dateChooser1.setToolTipText("");
		dateChooser1.setBounds(10, 214, 264, 38);
		panel.add(dateChooser1);
		
	}
}
